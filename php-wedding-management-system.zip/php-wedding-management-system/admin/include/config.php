<?php
    define('DB_HOST','localhost');
    define('DB_USER','root');
    define('DB_PASS','sysadmin');
    define('DB_NAME','phpwedmgmt');
?>